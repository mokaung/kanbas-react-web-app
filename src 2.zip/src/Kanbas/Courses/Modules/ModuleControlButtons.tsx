import { IoEllipsisVertical } from "react-icons/io5";
import { BsPlus } from "react-icons/bs";
import GreenCheckmark from "./GreenCheckmark";
import { FaTrash } from "react-icons/fa";
import { FaPencil } from "react-icons/fa6";
import FacultyProtection from "../../Account/FacultyProtection";
export default function ModuleControlButtons({
  moduleId,
  deleteModule,
  editModule,
}: {
  moduleId: string;
  deleteModule: (moduleId: string) => void;
  editModule: (moduleId: string) => void;
}) {
  return (
    <div className="float-end">
      <FacultyProtection>
      <FaPencil
        onClick={() => editModule(moduleId)}
        className="text-primary me-3"
      />
      </FacultyProtection>
      <FacultyProtection>
      <FaTrash
        className="text-danger me-2 mb-1"
        onClick={() => deleteModule(moduleId)}
      />
      </FacultyProtection>
      <GreenCheckmark />
      <FacultyProtection>
      <BsPlus className="fs-1" />
      </FacultyProtection>
      <IoEllipsisVertical className="fs-4" />
    </div>
  );
}
